namespace TravelAgency
{
    public enum TicketType
    {
        Air,
        Bus,
        Train
    }
}